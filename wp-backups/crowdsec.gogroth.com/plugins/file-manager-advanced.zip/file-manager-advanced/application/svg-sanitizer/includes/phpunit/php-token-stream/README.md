# phpunit/php-token-stream

[![CI Status](https://github.com/sebastianbergmann/php-token-stream/workflows/CI/badge.svg)](https://github.com/sebastianbergmann/php-token-stream/actions)
[![Type Coverage](https://shepherd.dev/github/sebastianbergmann/php-token-stream/coverage.svg)](https://shepherd.dev/github/sebastianbergmann/php-token-stream)

## Installation

You can add this library as a local, per-project dependency to your project using [Composer](https://getcomposer.org/):

```
composer require phpunit/php-token-stream
```

If you only need this library during development, for instance to run your project's test suite, then you should add it as a development-time dependency:

```
composer require --dev phpunit/php-token-stream
```
