<?php

declare(strict_types=1);

namespace MaxMind\Exception;

/**
 * This class represents an error authenticating.
 */
class AuthenticationException extends InvalidRequestException
{
}
