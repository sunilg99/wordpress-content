<?php // Silence is golden
// Folder name is api-key instead of apikey so uPress doesn't keep deleting this folder (issue #738)
