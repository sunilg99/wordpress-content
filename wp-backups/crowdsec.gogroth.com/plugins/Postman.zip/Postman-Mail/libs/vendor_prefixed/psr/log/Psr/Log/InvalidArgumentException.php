<?php

namespace PostSMTP\Vendor\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
