<?php return array('dependencies' => array('react', 'wp-dom-ready', 'wp-element', 'wp-url'), 'version' => '9b99dcd6cfaa72c66522');
