<?php
/**
 * Notification Settings of the plugin
 *
 * @package wsal
 *
 * @since 5.1.1
 */

// phpcs:disable
// phpcs:enable