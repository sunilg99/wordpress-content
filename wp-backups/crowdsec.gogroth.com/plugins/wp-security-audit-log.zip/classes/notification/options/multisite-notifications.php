<?php
/**
 * Build-in notification settings of the plugin
 *
 * @package wsal
 *
 * @since 5.2.0
 */

// phpcs:disable
// phpcs:enable